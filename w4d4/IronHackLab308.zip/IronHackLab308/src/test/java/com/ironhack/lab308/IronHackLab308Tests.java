package com.ironhack.lab308;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IronHackLab308Tests {

	@Test
	void contextLoads() {
	}

}
