package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Guest {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToMany(mappedBy = "guests")
    private Set<Event> events;

    @Enumerated(EnumType.STRING)
    private GuestStatus status;

    public Guest() {
    }

    public Guest(Integer id, Set<Event> events, GuestStatus status) {
        this.id = id;
        this.events = events;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<Event> getEvents() {
        return events;
    }

    public void setEvents(Set<Event> events) {
        this.events = events;
    }

    public GuestStatus getStatus() {
        return status;
    }

    public void setStatus(GuestStatus status) {
        this.status = status;
    }
}
