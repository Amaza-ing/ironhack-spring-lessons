package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Association {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @OneToMany(mappedBy = "association")
    private Set<Chapter> chapters;

    public Association() {
    }

    public Association(Integer id, Set<Chapter> chapters) {
        this.id = id;
        this.chapters = chapters;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Set<Chapter> getChapters() {
        return chapters;
    }

    public void setChapters(Set<Chapter> chapters) {
        this.chapters = chapters;
    }
}
