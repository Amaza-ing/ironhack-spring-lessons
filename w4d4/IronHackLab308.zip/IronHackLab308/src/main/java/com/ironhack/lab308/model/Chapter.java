package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Chapter {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", insertable = false)
    private Integer id;

    private String name;
    private Integer district;

    @OneToOne
    @JoinColumn(name = "president_id")
    private Member president;

    @OneToMany(mappedBy = "chapter")
    private Set<Member> members;

    @ManyToOne
    @JoinColumn(name = "association_id")
    private Association association;

    public Chapter() {
    }

    public Chapter(Integer id, Member president, Set<Member> members, Association association) {
        this.id = id;
        this.president = president;
        this.members = members;
        this.association = association;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Member getPresident() {
        return president;
    }

    public void setPresident(Member president) {
        this.president = president;
    }

    public Set<Member> getMembers() {
        return members;
    }

    public void setMembers(Set<Member> members) {
        this.members = members;
    }

    public Association getAssociation() {
        return association;
    }

    public void setAssociation(Association association) {
        this.association = association;
    }

    @Override
    public String toString() {
        return "Chapter{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", district=" + district +
                ", president=" + president +
                ", members=" + members +
                ", association=" + association +
                '}';
    }
}
