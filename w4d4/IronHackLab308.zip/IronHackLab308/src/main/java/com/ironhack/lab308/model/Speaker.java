package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Speaker {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "event_id")
    private Conference conference;

    private String name;




    public Speaker() {
    }

    public Speaker(Conference conference, String name) {
        this.conference = conference;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Conference getConference() {
        return conference;
    }

    public void setConference(Conference conference) {
        this.conference = conference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
