package com.ironhack.lab308.model;

public enum MemberStatus {
    ACTIVE,
    LAPSED
}
