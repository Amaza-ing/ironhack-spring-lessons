package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String title;
    private Date date;
    private Integer duration;

    @ManyToMany
    @JoinTable(
        name = "EventGuests",
        joinColumns = {@JoinColumn(name = "eventId", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "guestId", referencedColumnName = "id")})
    private Set<Guest> guests;

    public Event() {
    }




    public Event(String title, Date date, Integer duration, Set<Guest> guests) {
        this.title = title;
        this.date = date;
        this.duration = duration;
        this.guests = guests;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Set<Guest> getGuests() {
        return guests;
    }

    public void setGuests(Set<Guest> guests) {
        this.guests = guests;
    }
}
