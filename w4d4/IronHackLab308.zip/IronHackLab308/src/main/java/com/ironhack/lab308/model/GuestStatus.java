package com.ironhack.lab308.model;

public enum GuestStatus {
    ATTENDING,
    NOT_ATTENDING,
    NO_RESPONSE
}
