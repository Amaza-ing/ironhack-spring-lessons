package com.ironhack.lab308.model;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@PrimaryKeyJoinColumn(name = "id")
public class Conference extends Event{
    @OneToMany(mappedBy = "conference")
    private Set<Speaker> speakers;

    public Conference() {
    }

    public Conference(String title, Date date, Integer duration, Set<Guest> guests, Set<Speaker> speakers) {
        super(title, date, duration, guests);
        this.speakers = speakers;
    }

    public Set<Speaker> getSpeakers() {
        return speakers;
    }

    public void setSpeakers(Set<Speaker> speakers) {
        this.speakers = speakers;
    }
}
