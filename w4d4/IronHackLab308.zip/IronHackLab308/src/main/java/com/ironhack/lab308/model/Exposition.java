package com.ironhack.lab308.model;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import java.util.Date;
import java.util.Set;

@Entity
@PrimaryKeyJoinColumn(name = "id")
public class Exposition extends Event{

    public Exposition() {
    }

    public Exposition(String title, Date date, Integer duration, Set<Guest> guests) {
        super(title, date, duration, guests);
    }
}
